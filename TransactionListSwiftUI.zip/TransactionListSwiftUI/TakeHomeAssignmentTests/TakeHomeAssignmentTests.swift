//
//  TakeHomeAssignmentTests.swift
//  TakeHomeAssignmentTests
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import XCTest
@testable import TakeHomeAssignment

final class TakeHomeAssignmentTests: XCTestCase {

    // Test decoding a single transaction from transaction-list JSON
    func testDecodeTransactionListJSON() throws {
        
        let bundle = Bundle(for: type(of: self)) // test bundle
        guard let url = bundle.url(forResource: "transaction-list", withExtension: "json") else {
            XCTFail("transaction-list.json not found in test bundle")
            return
        }
        let data = try Data(contentsOf: url)
        let transactions = try TransactionService.decodeTransactions(from: data)

        XCTAssertEqual(transactions.count, 33)
        let transaction = transactions[0]

        XCTAssertEqual(transaction.id, "kDk81_4xGkWW_vOVP_ExwK7GVUlzQ5YtYcuZARHuAQg=")
        XCTAssertEqual(transaction.type, .debit)
        XCTAssertEqual(transaction.merchantName, "Mb - Cash Advance To - 1785")
        XCTAssertEqual(transaction.details, "Bill payment") // updated property name
        XCTAssertEqual(transaction.amount.currency, "CAD")
        XCTAssertEqual(transaction.shortCardSuffix, "8012")
        XCTAssertEqual(transaction.fromDisplayText, "Momentum Regular Visa (8012)")

        var calendar = Calendar(identifier: .iso8601)
        if let utc = TimeZone(secondsFromGMT: 0) {
            calendar.timeZone = utc
        }
        let comps = calendar.dateComponents([.year, .month, .day], from: transaction.postedDate)
        XCTAssertEqual(comps.year, 2021)
        XCTAssertEqual(comps.month, 5)
        XCTAssertEqual(comps.day, 31)
    }

    // Test formatted amount string from "transaction-list" JSON
    func testFormattedAmountContainsValue() throws {
        let bundle = Bundle(for: type(of: self)) // test bundle
        guard let url = bundle.url(forResource: "transaction-list", withExtension: "json") else {
            XCTFail("transaction-list.json not found in test bundle")
            return
        }
        let data = try Data(contentsOf: url)
        let transactions = try TransactionService.decodeTransactions(from: data)
        
        let transaction = transactions[0]

        let formatted = transaction.formattedAmount(locale: Locale(identifier: "en_CA"))
        XCTAssertTrue(formatted.contains("200.20"))
        XCTAssertTrue(formatted.contains("$"))
    }

    // Test multiple hardcoded transactions decode
    func testMultipleTransactionsDecode() throws {
        let json = """
        {
          "transactions": [
            {
              "key": "k1",
              "transaction_type": "CREDIT",
              "merchant_name": "Merchant 1",
              "description": "Payment 1",
              "amount": { "value": 100, "currency": "CAD" },
              "posted_date": "2021-05-30",
              "from_account": "Account 1",
              "from_card_number": "1111222233334444"
            },
            {
              "key": "k2",
              "transaction_type": "DEBIT",
              "merchant_name": "Merchant 2",
              "description": "Payment 2",
              "amount": { "value": 50, "currency": "CAD" },
              "posted_date": "2021-05-31",
              "from_account": "Account 2",
              "from_card_number": "5555666677778888"
            }
          ]
        }
        """

        let data = json.data(using: .utf8)!
        let transactions = try TransactionService.decodeTransactions(from: data)

        XCTAssertEqual(transactions.count, 2)

        XCTAssertEqual(transactions[0].id, "k1")
        XCTAssertEqual(transactions[0].type, .credit)
        XCTAssertEqual(transactions[0].details, "Payment 1")

        XCTAssertEqual(transactions[1].id, "k2")
        XCTAssertEqual(transactions[1].type, .debit)
        XCTAssertEqual(transactions[1].details, "Payment 2")
    }
}

