//
//  TransactionService.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Foundation

public enum TransactionServiceError: Error, LocalizedError {
    case resourceNotFound(String)
    case decodingFailed
    
    public var errorDescription: String? {
        switch self {
        case .resourceNotFound(let file):
            return "\(file) not found."
        case .decodingFailed:
            return "Failed to decode transactions."
        }
    }
}

public protocol TransactionServiceProtocol {
    func fetchTransactions() async throws -> [Transaction]
}

// MARK: - Transaction Service Implementation
struct TransactionService: TransactionServiceProtocol {
    private let urlString = "https://694acade26e870772066978f.mockapi.io/transactions"
    
    func fetchTransactions() async throws -> [Transaction] {
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              200..<300 ~= httpResponse.statusCode else {
            throw URLError(.badServerResponse)
        }
        
        // Decode JSON using custom date formatter
        let decoder = JSONDecoder.withISO8601Date()
        let transactions = try decoder.decode([Transaction].self, from: data)
        return transactions
    }
    
    public static func decodeTransactions(from data: Data) throws -> [Transaction] {
        let decoder = JSONDecoder()
        let df = DateFormatter()
        df.calendar = Calendar(identifier: .iso8601)
        df.locale = Locale(identifier: "en_US_POSIX")
        df.timeZone = TimeZone(secondsFromGMT: 0)
        df.dateFormat = "yyyy-MM-dd"
        decoder.dateDecodingStrategy = .formatted(df)
        
        do {
            let response = try decoder.decode(TransactionListResponse.self, from: data)
            return response.transactions
        } catch {
            throw TransactionServiceError.decodingFailed
        }
    }
}
