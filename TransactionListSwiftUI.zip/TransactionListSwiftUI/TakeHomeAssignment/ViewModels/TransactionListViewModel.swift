//
//  TransactionListViewModel.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Combine

import Foundation
import Combine

final class TransactionListViewModel: ObservableObject {
    @Published private(set) var transactions: [Transaction] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let service: TransactionServiceProtocol

    init(service: TransactionServiceProtocol? = nil) {
        self.service = service ?? TransactionService()
    }

    func loadTransactions() async {
        // Start loading on main thread
        await MainActor.run {
            self.isLoading = true
            self.errorMessage = nil
        }

        do {
            let fetchedTransactions = try await service.fetchTransactions()
            
            // Update UI on main thread
            await MainActor.run {
                self.transactions = fetchedTransactions
                self.isLoading = false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.transactions = []
                self.isLoading = false
            }
        }
    }
}
