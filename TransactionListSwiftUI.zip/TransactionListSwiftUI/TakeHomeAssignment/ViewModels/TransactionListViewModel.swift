//
//  TransactionListViewModel.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Foundation

@Observable
final class TransactionListViewModel {
    // Automatically observable properties
    private(set) var transactions: [Transaction] = []
    var isLoading: Bool = false
    var errorMessage: String?

    private let service: TransactionServiceProtocol

    init(service: TransactionServiceProtocol? = nil) {
        self.service = service ?? TransactionService()
    }

    func loadTransactions() async {
        // Set loading true immediately on main actor
        await MainActor.run {
            self.isLoading = true
        }

        var fetchedTransactions: [Transaction] = []
        var fetchError: String?

        do {
            // Fetch in background thread
            fetchedTransactions = try await service.fetchTransactions()
        } catch {
            fetchError = error.localizedDescription
        }

        // Single UI update on main actor
        await MainActor.run {
            self.transactions = fetchedTransactions
            self.errorMessage = fetchError
            self.isLoading = false
        }
    }
}
