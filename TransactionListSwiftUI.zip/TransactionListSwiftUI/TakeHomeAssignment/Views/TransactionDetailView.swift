//
//  TransactionDetailView.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import SwiftUI

struct TransactionDetailView: View {
    let transaction: Transaction
    @Environment(\.dismiss) private var dismiss

    private var statusColor: Color {
        transaction.type == .credit ? .green : .red
    }

    private var titleText: String {
        transaction.type == .credit ? "Credit transaction" : "Debit transaction"
    }

    var body: some View {
        VStack {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        HStack {
                            Spacer()
                            if transaction.type == .credit {
                                Image("success-icon")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 40, height: 40)
                            } else {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 40, weight: .regular))
                                    .foregroundColor(statusColor)
                            }
                            Spacer()
                        }

                        Text(titleText)
                            .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)

                        VStack(alignment: .leading, spacing: 8) {
                            Text("From")
                                .font(.footnote)
                                .foregroundColor(.secondary)

                            Text(transaction.fromAccount)
                                .font(.headline)
                                .fontWeight(.medium)
                                .foregroundColor(.secondary)
                            + Text(" (\(transaction.fromCardNumber.suffix(4)))")
                                .font(.headline)
                                .fontWeight(.regular)
                                .foregroundColor(.secondary)
                        }

                        Divider()

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Amount")
                                .font(.footnote)
                                .foregroundColor(.secondary)

                            Text(transaction.formattedAmount())
                                .font(.headline)
                                .fontWeight(.medium)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()

                        TransactionTooltipView()
                    }
                    .padding(16)
                }

                // Close button inside rectangle
                Button {
                    dismiss()
                } label: {
                    Text("Close")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 60)
                }
                .background(Color.red)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .padding(.horizontal, 30) // left/right inside rectangle
                .padding(.bottom, 30)     // distance from rectangle bottom
            }
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
            // OUTER padding to control rectangle distance from main view edges
            .padding(.top, 10)       // 10px from top
            .padding(.leading, 10)   // 10px from left
            .padding(.trailing, 10)  // 10px from right
            .padding(.bottom, 50)   // 50px from main view bottom
        }
        .navigationTitle("Transaction Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}
