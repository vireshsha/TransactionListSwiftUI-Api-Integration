//
//  TransactionTooltipView.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import SwiftUI

struct TransactionTooltipView: View {
    @State private var isExpanded = false

    private let collapsedMessage = "Transactions are processed Monday to Friday (excluding holidays)."
    private let expandedMessage = "\n\nTransactions made before 8:30 pm ET Monday to Friday (excluding holidays) will show up in your account the same day."

    private var attributedText: AttributedString {
        var attributedString = AttributedString(isExpanded ? collapsedMessage + expandedMessage + " Show less" : collapsedMessage + " Show more")
        attributedString.font = .callout.weight(.semibold)
        attributedString.foregroundColor = .secondary
        
        let linkText = isExpanded ? "Show less" : "Show more"
        if let range = attributedString.range(of: linkText) {
            attributedString[range].foregroundColor = .blue
            attributedString[range].font = .callout.weight(.semibold)
        }

        return attributedString
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 12) {
                Image("buddy-tip-icon")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                    .padding(.top, 2)

                VStack(alignment: .leading, spacing: 6) {
                    Text(attributedText)
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                isExpanded.toggle()
                            }
                        }
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(Color.white)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
    }
}
