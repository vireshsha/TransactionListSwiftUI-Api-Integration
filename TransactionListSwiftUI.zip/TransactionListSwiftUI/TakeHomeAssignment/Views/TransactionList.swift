//
//  TransactionList.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import SwiftUI

struct TransactionList: View {
    @State private var viewModel = TransactionListViewModel()

    init() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .white

        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.gray,
            .font: UIFont.systemFont(ofSize: 20, weight: .medium)
        ]
        appearance.largeTitleTextAttributes = [
            .foregroundColor: UIColor.gray,
            .font: UIFont.systemFont(ofSize: 30, weight: .medium)
        ]

        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }

    var body: some View {
        NavigationStack {
            List(viewModel.transactions) { tx in
                NavigationLink(value: tx) {
                    TransactionRowView(transaction: tx)
                        .padding(.vertical, 8)
                }
                .listRowSeparator(.visible)
                .accessibilityIdentifier("transactionCell_\(tx.id)")
            }
            .accessibilityIdentifier("transactionList")
            .listStyle(.plain)
            .navigationTitle("Transactions")
            .navigationBarTitleDisplayMode(.inline)

            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.black.opacity(0.1))
                } else if let message = viewModel.errorMessage {
                    Text(message)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.red)
                        .padding()
                }
            }

            .task {
                if viewModel.transactions.isEmpty {
                    await viewModel.loadTransactions()
                }
            }

            .navigationDestination(for: Transaction.self) { tx in
                TransactionDetailView(transaction: tx)
            }
        }
    }
}
