//
//  Transaction.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Foundation

// MARK: - TransactionType
public enum TransactionType: String, Codable, CaseIterable {
    case credit = "CREDIT"
    case debit = "DEBIT"
}

// MARK: - MoneyAmount
public struct MoneyAmount: Codable, Equatable, Hashable {
    public let value: Double
    public let currency: String
    
    public func formattedAmount(locale: Locale = Locale(identifier: "en_CA")) -> String {
        let formatter = NumberFormatter()
        formatter.locale = locale
        formatter.numberStyle = .currency
        formatter.currencyCode = currency
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: value)) ?? "\(value)"
    }
}

// MARK: - Transaction
public struct Transaction: Identifiable, Codable, Equatable, Hashable {
    public let id: String                   // mapped from "key"
    public let type: TransactionType        // mapped from "transaction_type"
    public let merchantName: String
    public let description: String?        // optional
    public let amount: MoneyAmount
    public let postedDate: Date             // decoded from "posted_date"
    public let fromAccount: String
    public let fromCardNumber: String

    // Computed properties
    public var shortCardSuffix: String {
        String(fromCardNumber.suffix(4))
    }

    public var fromDisplayText: String {
        "\(fromAccount) (\(shortCardSuffix))"
    }

    public func formattedAmount(locale: Locale = Locale(identifier: "en_CA")) -> String {
        amount.formattedAmount(locale: locale)
    }

    // Coding keys for JSON mapping
    enum CodingKeys: String, CodingKey {
        case id = "key"
        case type = "transaction_type"
        case merchantName = "merchant_name"
        case description
        case amount
        case postedDate = "posted_date"
        case fromAccount = "from_account"
        case fromCardNumber = "from_card_number"
    }
}

// MARK: - Transaction List Response
public struct TransactionListResponse: Codable, Equatable {
    public let transactions: [Transaction]
}

// MARK: - JSON Decoder Helper for Date
public extension JSONDecoder {
    static func withISO8601Date() -> JSONDecoder {
        let decoder = JSONDecoder()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd" // matches your posted_date
        decoder.dateDecodingStrategy = .formatted(formatter)
        return decoder
    }
}
